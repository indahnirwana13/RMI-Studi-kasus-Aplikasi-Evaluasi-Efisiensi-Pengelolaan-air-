import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.io.*;
import java.net.*;
import java.util.HashMap;
import java.util.Map;

public class WaterTreatmentEvaluationClient {

    private JFrame frame;
    private JTextField turbidityRawField, tdsRawField, turbidityTreatedField, tdsTreatedField;
    private JTextField capacityField, productionField;
    private JTextArea resultArea;

    public WaterTreatmentEvaluationClient() {
        frame = new JFrame("Water Treatment Evaluation Client");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(900, 720);
        frame.setLayout(new GridLayout(9, 2, 10, 10));

        // Input fields for raw water
        frame.add(new JLabel("Kekeruhan Air Baku (NTU):"));
        turbidityRawField = new JTextField();
        frame.add(turbidityRawField);

        frame.add(new JLabel("TDS Air Baku (mg/L):"));
        tdsRawField = new JTextField();
        frame.add(tdsRawField);

        // Input fields for treated water
        frame.add(new JLabel("Kekeruhan Air Olahan (NTU):"));
        turbidityTreatedField = new JTextField();
        frame.add(turbidityTreatedField);

        frame.add(new JLabel("TDS Air Olahan (mg/L):"));
        tdsTreatedField = new JTextField();
        frame.add(tdsTreatedField);

        // Input fields for capacity and production
        frame.add(new JLabel("Kapasitas Desain (liter/detik):"));
        capacityField = new JTextField();
        frame.add(capacityField);

        frame.add(new JLabel("Produksi Aktual (liter/detik):"));
        productionField = new JTextField();
        frame.add(productionField);

        // Button to calculate efficiency
        JButton calculateButton = new JButton("Hitung Efisiensi");
        frame.add(calculateButton);

        // Area to display results
        resultArea = new JTextArea();
        resultArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultArea);
        scrollPane.setPreferredSize(new Dimension(900, 720)); 
        frame.add(scrollPane);

        // Add button action listener
        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sendToServer();
            }
        });

        frame.setVisible(true);
    }

    private void sendToServer() {
    new Thread(() -> {
        try (Socket socket = new Socket("localhost", 8080);
             ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
             ObjectInputStream in = new ObjectInputStream(socket.getInputStream())) {

            System.out.println("Connecting to server...");

            // Collect input values
            Map<String, Double> rawWater = new HashMap<>();
            rawWater.put("turbidity", Double.parseDouble(turbidityRawField.getText()));
            rawWater.put("TDS", Double.parseDouble(tdsRawField.getText()));

            Map<String, Double> treatedWater = new HashMap<>();
            treatedWater.put("turbidity", Double.parseDouble(turbidityTreatedField.getText()));
            treatedWater.put("TDS", Double.parseDouble(tdsTreatedField.getText()));

            double capacity = Double.parseDouble(capacityField.getText());
            double production = Double.parseDouble(productionField.getText());

            System.out.println("Sending data to server...");

            // Send input to server
            out.writeObject(rawWater);
            out.writeObject(treatedWater);
            out.writeDouble(capacity);
            out.writeDouble(production);

            // Flush output to ensure data is sent completely
            out.flush();

            // Receive results from server
            System.out.println("Waiting for response from server...");
            Map<String, Double> parameterEfficiency = (Map<String, Double>) in.readObject();
            Double productionEfficiency = (Double) in.readObject();

            // Display results
            SwingUtilities.invokeLater(() -> {
                StringBuilder result = new StringBuilder();
                result.append("Efisiensi Parameter Pengolahan Air:\n");
                for (String param : parameterEfficiency.keySet()) {
                    Double eff = parameterEfficiency.get(param);
                    if (eff != null) {
                        result.append(String.format("  %s: %.2f%%\n", param, eff));
                    } else {
                        result.append(String.format("  %s: Tidak dapat dihitung\n", param));
                    }
                }

                result.append("\nEfisiensi Penyediaan Air:\n");
                if (productionEfficiency != null) {
                    result.append(String.format("  %.2f%%\n", productionEfficiency));
                } else {
                    result.append("  Tidak dapat dihitung\n");
                }

                resultArea.setText(result.toString());
                System.out.println("Response displayed in GUI.");
            });

        } catch (Exception ex) {
            SwingUtilities.invokeLater(() -> {
                JOptionPane.showMessageDialog(frame, "Terjadi kesalahan: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            });
            ex.printStackTrace();
        }
    }).start();
}


    public static void main(String[] args) {
        new WaterTreatmentEvaluationClient();
    }
}
