import java.io.*;
import java.net.*;
import java.util.HashMap;
import java.util.Map;

public class WaterTreatmentEvaluationServer {

    public static Map<String, Double> calculateEfficiency(Map<String, Double> rawWater, Map<String, Double> treatedWater) {
        Map<String, Double> efficiency = new HashMap<>();
        for (String param : rawWater.keySet()) {
            if (treatedWater.containsKey(param)) {
                double rawValue = rawWater.get(param);
                double treatedValue = treatedWater.get(param);
                if (rawValue > 0) {
                    double eff = ((rawValue - treatedValue) / rawValue) * 100;
                    efficiency.put(param, eff);
                } else {
                    efficiency.put(param, null);
                }
            }
        }
        return efficiency;
    }

    public static Double calculateWaterProductionEfficiency(double capacity, double production) {
        if (capacity > 0) {
            return (production / capacity) * 100;
        }
        return null;
    }

    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(8080);
        System.out.println("Server is running on port 8080...");

        while (true) {
            Socket clientSocket = serverSocket.accept();
            System.out.println("Client connected: " + clientSocket.getInetAddress());
            new Thread(() -> handleClient(clientSocket)).start();
        }
    }

   private static void handleClient(Socket clientSocket) {
    try (ObjectInputStream in = new ObjectInputStream(clientSocket.getInputStream());
         ObjectOutputStream out = new ObjectOutputStream(clientSocket.getOutputStream())) {

        // Receive input data from client
        try {
            Map<String, Double> rawWater = (Map<String, Double>) in.readObject();
            Map<String, Double> treatedWater = (Map<String, Double>) in.readObject();
            double capacity = in.readDouble();
            double production = in.readDouble();

            System.out.println("Received data from client: ");
            System.out.println("Raw Water: " + rawWater);
            System.out.println("Treated Water: " + treatedWater);
            System.out.println("Capacity: " + capacity);
            System.out.println("Production: " + production);

            // Perform calculations
            Map<String, Double> parameterEfficiency = calculateEfficiency(rawWater, treatedWater);
            Double productionEfficiency = calculateWaterProductionEfficiency(capacity, production);

            // Send results back to client
            out.writeObject(parameterEfficiency);
            out.writeObject(productionEfficiency);
            System.out.println("Results sent to client.");
        } catch (EOFException e) {
            System.out.println("Error: Data incomplete or connection closed by client.");
        }

    } catch (IOException | ClassNotFoundException e) {
        e.printStackTrace();
    }
}

}